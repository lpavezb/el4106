Para correr la tarea se tienen 3 funciones: p4a, p5a y p5b, basta con descomentar la que se va a usar y comentar las otras 2 en el main (linea 272).

p4a muestra una figura con el accuracy del conjunto de validacion, y hace print de la matriz de confusion mas los datos pedidos. Puede demorarse de 4 a 5 minutos
p5a muestra una figura con 3 curvas, cada curva con un numero diferente de neuronas en la capa oculta, se hace print de las matrices. Puede demorarse alrededor de 15 minutos.
p5b muestra 2 figuras, una con sigmoide y otra con relu, tambien se hace print de sus matrices de confusion. Puede demorarse alrededor de 30 minutos.

Las bases de datos deben encontrarse en la misma carpeta del programa.
Se guardaran figuras en la misma carpeta del programa.

Version de python: 3.5
Version de tensorflow, tensorflow-gpu: 1.13.1
Version de Cuda: 10.0
Version de Cudnn: 7.5