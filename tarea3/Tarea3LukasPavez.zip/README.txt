Para correr la tarea se debe ejecutar el programa tarea3.py, esto generará las 4 curvas pedidas para comparar los kernels 
y una quinta curva con el mejor kernel encontrado, se guardarán 2 gráficos en la carpeta del programa. 
El programa se demora aproximadamente 200 segundos en finalizar.

Version de python: 3.5
Versión de sklearn: 0.20.3