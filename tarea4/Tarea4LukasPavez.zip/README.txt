Para correr la tarea se debe ejecutar el programa tarea4.py, esto realizara las 18 pruebas pedidas en la tarea e imprimira las tablas con los resultados.

Version de python: 3.5
Versión de sklearn: 0.21.0